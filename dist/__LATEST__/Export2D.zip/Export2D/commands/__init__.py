"""Export2D - Export Fusion 360 model faces as PDF or DXF files"""

__version__ = '0.1.0'
__author__ = 'Patrick Rainsberry <patrick.rainsberry@autodesk.com>'
__all__ = []
